import React from "react";

function About() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">About BudgetBuddy</h2>
      <p>BudgetBuddy is your personal finance tracking tool.</p>
    </div>
  );
}

export default About;
