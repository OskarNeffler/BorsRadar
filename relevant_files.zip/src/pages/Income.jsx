import React from "react";

const Income = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold">Inkomster</h2>
      <p>Här kan du lägga till dina inkomster.</p>
    </div>
  );
};

export default Income;
